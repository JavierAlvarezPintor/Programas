package es.unileon.prg1.ticTacToe;
public class MainTicTacToe {

	public static void main(String[] args) {

		// The game is created
		TicTacToe starter = new TicTacToe();
		// The game begins
		starter.play();
	}

}
